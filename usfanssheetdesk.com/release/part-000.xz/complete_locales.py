"""Offline translation and complete coverage checks; never sends guide content to another service."""
from pathlib import Path
import os,re,json,time,concurrent.futures
os.environ['UCX_VFS_ENABLE']='n'
import ctranslate2,sentencepiece
R=Path(__file__).parent;M=os.environ.get('USFANS_TRANSLATION_MODEL_DIR',str(R/'.cache/m2m'));C=R/'locale-checkpoints';C.mkdir(exist_ok=True)
languages=[('de','German'),('fr','French'),('es','Spanish'),('it','Italian'),('pt','Portuguese'),('nl','Dutch'),('pl','Polish'),('sv','Swedish'),('da','Danish'),('no','Norwegian'),('fi','Finnish'),('cs','Czech'),('ro','Romanian'),('hu','Hungarian'),('el','Greek'),('tr','Turkish'),('ru','Russian'),('uk','Ukrainian'),('ar','Arabic'),('ja','Japanese'),('ko','Korean'),('th','Thai')]
strings=set()
for name in ['guide.json','guide-mobile.json']:
 d=json.loads((R/'dist'/name).read_text());strings.add(d['illustrationNote'])
 for s in d['steps']:
  for k in ['title','where','check','captureNote']:
   if s.get(k):strings.add(s[k])
  strings.update(s['actions'])
  for row in s.get('fieldRows',[]):strings.update(row[:2])
  if s.get('example'):strings.add(s['example']['label'])
  for v in s['visuals']:
   strings.update(v['operations']);strings.update(v[k] for k in ['operationTitle','caption','result'])
for f in json.loads((R/'faq-content.json').read_text()):strings.add(f['question']);strings.update(f['paragraphs'])
for file in ['app.js','visual-search.js']:
 js=(R/'dist'/file).read_text()
 for pattern in [r"(?<![\w])(?:t|tr)\('([^'\n]+)'\)",r"(?<![\w])l\('([^'\n]+)',"]:strings.update(re.findall(pattern,js))
strings.update(['Language','Currency','Open menu','Choose another photo','Search by photo','Find a similar item.','Upload a product photo','Try a sample photo','Shoes','Trousers'])
strings.update(['The source does not currently provide separate style photos for this item.','Style photos have not been imported for this item yet.'])
strings.discard('');source=sorted(strings);(R/'locale-source.json').write_text(json.dumps(source,ensure_ascii=False,indent=2))
sp=sentencepiece.SentencePieceProcessor(model_file=M+'/sentencepiece.bpe.model');engine=ctranslate2.Translator(M,device='cpu',compute_type='int8',inter_threads=2,intra_threads=3)
labels=['Available Payment Methods','Outer Packing Method','Confirm Password','Payment Pending','Shipping Method','Billing Address','Custom Take Photo','Packing Details','Modify Route','Shipping Fee','Leave Message','Order Enquiry','Confirm Pay','Buy on USFans','Join USFans','Buy now','Log In','Sign up','Warehouse','Inventory','Quantity','Password','Account','Parcel','Coupon','Submit','Weidian','USFans','Sheet Desk','Email','Color','Size','Order','Search','QC']
def encode(s):return ['__en__']+sp.encode(s,out_type=str)+['</s>']
def decode(r):return sp.decode([x for x in r.hypotheses[0] if not x.startswith('__') and x not in ['<s>','</s>']])
def protected(s):
 names=labels if len(s)>55 or '/' in s else ['USFans','Weidian','Sheet Desk']
 p=re.compile('|'.join(map(re.escape,sorted(names,key=len,reverse=True)))+r'|\d+(?:[.,]\d+)*');values=[]
 def replace(m):values.append(m.group());return 'ZXQ'+str(len(values)-1)+'ZXQ'
 return p.sub(replace,s),values
def run(item):
 code,name=item;path=C/(code+'.json');done=json.loads(path.read_text()) if path.exists() else (json.loads((R/'locale-durable'/(code+'.json')).read_text()) if (R/'locale-durable'/(code+'.json')).exists() else {});pending=[x for x in source if x not in done];start=time.time()
 for offset in range(0,len(pending),32):
  batch=pending[offset:offset+32];data=[protected(x) for x in batch];results=engine.translate_batch([encode(x) for x,values in data],target_prefix=[['__'+code+'__']]*len(batch),beam_size=1,max_batch_size=32,max_decoding_length=384,repetition_penalty=1.05)
  for original,(text,values),r in zip(batch,data,results):
   translated=decode(r)
   if any('ZXQ'+str(i)+'ZXQ' not in translated for i in range(len(values))):
    parts=re.split(r'(ZXQ\d+ZXQ)',text);fragments=[p for p in parts if re.search('[A-Za-z]',p) and not re.fullmatch(r'ZXQ\d+ZXQ',p)];fr=engine.translate_batch([encode(x) for x in fragments],target_prefix=[['__'+code+'__']]*len(fragments),beam_size=2,max_decoding_length=384) if fragments else [];it=iter(decode(x) for x in fr);translated=' '.join(next(it) if re.search('[A-Za-z]',p) and not re.fullmatch(r'ZXQ\d+ZXQ',p) else p for p in parts)
   for i,value in enumerate(values):translated=translated.replace('ZXQ'+str(i)+'ZXQ',value)
   if not translated.strip() or re.search(r'ZXQ\d',translated):raise RuntimeError(code+' invalid translation')
   done[original]=translated
  path.write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n');print(code,min(offset+32,len(pending)),'/',len(pending),round(time.time()-start),flush=True)
 return code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,languages))
dictionary=json.loads((R/'dist/translations.json').read_text())
for code,name in languages:
 translated=json.loads((C/(code+'.json')).read_text());assert all(s in translated for s in source)
 dictionary.setdefault(code,{})
 for s in source:dictionary[code].setdefault(s,translated[s])
zh={'Search by photo':'图片搜索','Find a similar item.':'用照片寻找相似商品。','Upload a product photo':'上传商品照片','Choose another photo':'换一张照片','Try a sample photo':'试用示例照片','Shoes':'鞋子','Trousers':'裤子','Similar products':'相似商品','Loading image search…':'正在加载图片搜索…','Matching your photo…':'正在匹配图片…','Download progress':'下载进度','Load more matches':'加载更多相似商品','Use JPG, PNG or WebP, up to 15 MB.':'支持 JPG、PNG、WebP，文件不超过15 MB。','No confident visual matches. Try a clearer photo of one item.':'暂未找到可靠的相似商品，请换一张单件商品的清晰照片。','Image search could not load. Please try again.':'图片搜索加载失败，请稍后重试。','Choose a clear photo of one item. Your photo is processed on this device.':'选择单件商品的清晰照片。照片仅在本设备处理。','First use downloads about 90 MB. It is cached for future searches.':'首次使用需下载约90 MB资源，之后会缓存供再次搜索使用。','Visual similarity, not an identity or authenticity guarantee.':'结果按视觉相似度匹配，不代表款式完全相同或正品鉴定。','Your selected photo':'你选择的照片'}
dictionary.setdefault('zh-CN',{}).update(zh);(R/'dist/translations.json').write_text(json.dumps(dictionary,ensure_ascii=False,separators=(',',':')))
(R/'localization-coverage.json').write_text(json.dumps({'languages':24,'complete_string_coverage':True,'source_strings':len(source),'additional_languages':{c:len(json.loads((C/(c+'.json')).read_text())) for c,n in languages},'method':'Offline Meta M2M100418M int8; protected UI names/numerals; curated existing translations retained','native_speaker_proofread':False},indent=2))
print('Complete24language guide/FAQ coverage',flush=True)
