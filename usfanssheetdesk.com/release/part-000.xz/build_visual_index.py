"""Paced, resumable real-image index with durable vector checkpoints."""
from pathlib import Path
import json,hashlib,time,concurrent.futures,subprocess,threading,os
from urllib.parse import urlsplit,urlunsplit,parse_qsl,urlencode
import numpy as np
from PIL import Image,ImageOps
from importlib.metadata import version
if version("onnxruntime")!="1.23.2":raise RuntimeError("Install the pinned onnxruntime==1.23.2 runtime before generating the index")
import onnxruntime as rt
# Disable optional vendor telemetry before creating any inference session.
rt.disable_telemetry_events()
R=Path(__file__).parent;C=Path(os.environ.get('USFANS_COVER_CACHE',str(R/'.cache/covers')));W=R/'visual-workstate';C.mkdir(parents=True,exist_ok=True);W.mkdir(exist_ok=True)
import shutil
runtime_info=W/'runtime.json';durable=R/'visual-durable'
if (W/'vectors.npz').exists() and (not runtime_info.exists() or json.loads(runtime_info.read_text()).get('runtime')!='1.23.2'):
 if not(durable/'runtime.json').exists() or json.loads((durable/'runtime.json').read_text()).get('runtime')!='1.23.2':raise RuntimeError('Unknown-runtime vectors must be recomputed before resuming')
 for name in ['vectors.npz','sources.json','runtime.json']:shutil.copy(durable/name,W/name)
elif not(W/'vectors.npz').exists() and (durable/'runtime.json').exists():
 for name in ['vectors.npz','sources.json','runtime.json']:shutil.copy(durable/name,W/name)
model_path=Path(os.environ.get('USFANS_CLIP_MODEL',str(R/'.cache/clip-vision.onnx')))
with model_path.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()=='583fd1110a514667812fee7d684952aaf82a99b959760c8d7dca7e0ab9839299','UnexpectedCLIPmodelweights'
catalog=json.loads((R/'dist/catalog.json').read_text());checkpoint=W/'vectors.npz';sources=json.loads((W/'sources.json').read_text()) if (W/'sources.json').exists() else {};vectors=dict(np.load(checkpoint)) if checkpoint.exists() else {};opts=rt.SessionOptions();opts.intra_op_num_threads=1;opts.inter_op_num_threads=1;session=rt.InferenceSession(str(model_path),sess_options=opts,providers=['CPUExecutionProvider']);stop=threading.Event()
def save():
 runtime_info.write_text(json.dumps({'runtime':'1.23.2','model_revision':'6b7c523703ae26e39be4b03774966f8571c7f523','telemetry_disabled':True}));temp=W/'vectors.tmp.npz';np.savez_compressed(temp,**vectors);temp.replace(checkpoint);(W/'sources.json').write_text(json.dumps(sources));print('Checkpoint',len(vectors),'/',len(catalog),flush=True)
def image_vector(path):
 im=ImageOps.fit(ImageOps.exif_transpose(Image.open(path)).convert('RGB'),(224,224),method=Image.Resampling.BICUBIC);a=(np.asarray(im,np.float32)/255-np.array([.48145466,.4578275,.40821073],np.float32))/np.array([.26862954,.26130258,.27577711],np.float32);v=session.run(None,{'pixel_values':a.transpose(2,0,1)[None]})[0][0];return v/np.linalg.norm(v)
items=[]
for p in catalog:
 if p['id'] in vectors:continue
 original=p['image'];path=C/(hashlib.sha256(original.encode()).hexdigest()+'.jpg');role='catalogue cover'
 if not path.exists():
  g=json.loads((R/'dist/data/galleries'/(p['id']+'.json')).read_text());original=g['carousel'][0];path=C/(hashlib.sha256(original.encode()).hexdigest()+'.jpg');role='verified original seller carousel'
 url=original
 if 'geilicdn.com' in url:
  u=urlsplit(url);q=dict(parse_qsl(u.query));q.update(w='384',h='384',cp='0');url=urlunsplit((u.scheme,u.netloc,u.path,urlencode(q),u.fragment))
 items.append({'id':p['id'],'category':p['cat'],'original':original,'url':url,'path':str(path),'role':role})
pending=[]
for x in items:
 try:
  if not Path(x['path']).exists():pending.append(x);continue
  vectors[x['id']]=image_vector(x['path']);sources[x['id']]={'url':x['original'],'role':x['role']}
  if len(vectors)%100==0:save()
 except Exception:
  Path(x['path']).unlink(missing_ok=True);pending.append(x)
save();errorlog=C.parent/'visual-progress.log';not_before=errorlog.stat().st_mtime+600 if errorlog.exists() else 0
# A source429 was observed before this paced run. Respect a full cooldown.
not_before=max(not_before,time.time()+1)
while time.time()<not_before:time.sleep(min(20,not_before-time.time()))
start_lock=threading.Lock();next_start=0
def download(x):
 global next_start
 with start_lock:
  if stop.is_set():return x,None,"cancelled"
  delay=max(0,next_start-time.monotonic())
  if delay:time.sleep(delay)
  next_start=time.monotonic()+1
 if stop.is_set():return x,None,'cancelled'
 p=subprocess.run(['curl','-fLsS','--max-time','120','-o',x['path'],'-w','%{http_code}',x['url']],capture_output=True,text=True)
 if p.returncode:
  stop.set();return x,None,'HTTP '+p.stdout+' '+p.stderr[:200]
 try:return x,image_vector(x['path']),None
 except Exception as e:stop.set();return x,None,str(e)
errors=[];futures=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for x in pending:
  if stop.is_set():break
  # Timing controls STARTS explicitly; curl --rate does not pace parallel transfers.
  futures.append(pool.submit(download,x))
  while len(futures)>=16 and not any(f.done() for f in futures):time.sleep(.1)
  complete=[f for f in futures if f.done()]
  for f in complete:
   futures.remove(f);x,v,error=f.result()
   if error:errors.append({'id':x['id'],'error':error});print(errors[-1],flush=True)
   else:vectors[x['id']]=v;sources[x['id']]={'url':x['original'],'role':x['role']}
  if complete and len(vectors)//100!=(len(vectors)-len(complete))//100:save()
 for f in futures:
  x,v,error=f.result()
  if error:errors.append({'id':x['id'],'error':error})
  else:vectors[x['id']]=v;sources[x['id']]={'url':x['original'],'role':x['role']}
save()
if errors or len(vectors)!=len(catalog):(W/'errors.json').write_text(json.dumps(errors,indent=2));raise SystemExit('Paused; index incomplete, do not publish')
(W/'errors.json').unlink(missing_ok=True)
out=R/'dist/visual';out.mkdir(exist_ok=True);matrix=np.rint(np.clip(np.stack([vectors[p['id']] for p in catalog]),-1,1)*127).astype(np.int8);(out/'embeddings.i8').write_bytes(matrix.tobytes());(out/'index.json').write_text(json.dumps({'count':len(catalog),'dimensions':512,'encoder_runtime':'onnxruntime1.23.2','telemetry_disabled':True,'model':'Xenova/clip-vit-base-patch32','revision':'6b7c523703ae26e39be4b03774966f8571c7f523','items':[{'id':p['id'],'category':p['cat']} for p in catalog]},separators=(',',':')))
for cat,name in [(0,'shoes'),(4,'trousers')]:
 p=next(p for p in catalog if p['cat']==cat);src=sources[p['id']]['url'];path=C/(hashlib.sha256(src.encode()).hexdigest()+'.jpg');Image.open(path).convert('RGB').save(out/('sample-'+name+'.jpg'),quality=90)
(out/'NOTICE.txt').write_text('Image embeddings: OpenAI CLIP, MIT; ONNX conversion by Xenova. Runtime: Microsoft ONNX Runtime Web, MIT. Uploaded photos are processed locally and are not transmitted.\n');print('Complete visual index',len(catalog),flush=True)
